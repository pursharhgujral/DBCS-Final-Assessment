package solution;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class Userinterface {
	Stage theStage;
	/**********************************************************************************************
	 * 
	 * Attributes
	 * 
	 **********************************************************************************************/

	/*
	 * Constants used to parameterize the graphical user interface. We do not use a
	 * layout manager for this application. Rather we manually control the location
	 * of each graphical element for exact control of the look and feel.
	 */
	private final double BUTTON_WIDTH = 60;
	private final double BUTTON_OFFSET = BUTTON_WIDTH / 2;

	// These are the application values required by the user interface
	private Label label_Doublemainline = new Label("Admin Function");

	
	
	private Button ind_score = new Button(" Delete Record");
	private Button student = new Button(" Add Record");
	private Button teacher = new Button(" Modify Record");
	private Button record = new Button(" View Record");
	Connection con;
	TextField DataSource1 = new TextField();
	TextField DataSource2 = new TextField();
	TextField DataSource3 = new TextField();
	TextField DataSource4 = new TextField();
	TextField DataSource5 = new TextField();
	TextField DataSource6 = new TextField();
	TextField DataSource7 = new TextField();
	TextField DataSource8 = new TextField();
	
Label label1= new Label(" Reg_No");
Label label2= new Label(" Roll_No");
Label label3= new Label(" Name");
Label label4= new Label(" Father_Name");
Label label5= new Label(" Mother_Name");
Label label6= new Label(" Course");
Label label7= new Label(" Semester");
Label label8= new Label(" Year");

	private double buttonSpace;

	public Userinterface(Pane theRoot, Stage Stage) {

		// There are five gaps. Compute the button space accordingly.
		buttonSpace = mainline.WINDOW_WIDTH / 5;

		// Label theScene with the name of the mainline, centered at the top of the pane
		setupLabelUI(label_Doublemainline, "Arial", 24, mainline.WINDOW_WIDTH, Pos.CENTER, 0, 10);

		// Button UI
		setupButtonUI(ind_score, "Symbol", 16, BUTTON_WIDTH, Pos.BASELINE_CENTER, 2.6 * buttonSpace - BUTTON_OFFSET + 150,
				200);
		
		setupButtonUI(student, "Symbol", 16, BUTTON_WIDTH, Pos.BASELINE_CENTER, 2.6 * buttonSpace - BUTTON_OFFSET+ 150,
				100);
		
		setupButtonUI(teacher, "Symbol", 16, BUTTON_WIDTH, Pos.BASELINE_CENTER, 2.6 * buttonSpace - BUTTON_OFFSET+ 150,
				300);
		setupButtonUI(record, "Symbol", 16, BUTTON_WIDTH, Pos.BASELINE_CENTER, 2.6 * buttonSpace - BUTTON_OFFSET+ 150,
				400);

		DataSource1.setLayoutX(300);
		DataSource1.setLayoutY(50);	
		DataSource2.setLayoutX(300);
		DataSource2.setLayoutY(100);
		
		DataSource3.setLayoutX(300);
		DataSource3.setLayoutY(150);
		
		DataSource4.setLayoutX(300);
		DataSource4.setLayoutY(200);
		
		DataSource5.setLayoutX(300);
		DataSource5.setLayoutY(250);
		
		DataSource6.setLayoutX(300);
		DataSource6.setLayoutY(300);
		
		DataSource7.setLayoutX(300);
		DataSource7.setLayoutY(350);
		
		DataSource8.setLayoutX(300);
		DataSource8.setLayoutY(400);
		
		label1.setLayoutX(100);
		label1.setLayoutY(50);	
		
		label2.setLayoutX(100);
		label2.setLayoutY(100);	
		
		label3.setLayoutX(100);
		label3.setLayoutY(150);	
		
		label4.setLayoutX(100);
		label4.setLayoutY(200);	
		
		label5.setLayoutX(100);
		label5.setLayoutY(250);	
		
		label6.setLayoutX(100);
		label6.setLayoutY(300);	
		
		label7.setLayoutX(100);
		label7.setLayoutY(350);	
		
		label8.setLayoutX(100);
		label8.setLayoutY(400);	
		
		
		
		ind_score.setOnAction((event) -> {
			try {
				delete();
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			}
		);
		
		
		
		
		student.setOnAction((event) -> {
		try {
			exceltomysql();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		}
	);
		
		teacher.setOnAction((event) -> {
			try {
				update();
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			}
		);
		
		record.setOnAction((event) -> {
			try {
				result();
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			}
		);

		// Place all of the just-initialized GUI elements into the pane
		theRoot.getChildren().addAll(label_Doublemainline, ind_score,DataSource1,DataSource2,record,teacher,DataSource3,DataSource4,DataSource5,DataSource6,DataSource7,DataSource8,student,label1,label2,label3,label4,label5,label6,label7,label8);

	}
	
	
	


	private void update() throws SQLException, ClassNotFoundException, NullPointerException{
		
		


		try{
		    Class.forName("com.mysql.jdbc.Driver");
		    con = DriverManager.getConnection("jdbc:mysql://localhost/finalassessmentpaper?autoReconnect=true&useSSL=false",
					"root", "309919");
		    con.setAutoCommit(false);
		    PreparedStatement pstm = null ;
		    PreparedStatement pstm1 = null ;
		    PreparedStatement pstm2 = null ;
		    PreparedStatement pstm3 = null ;
		    PreparedStatement pstm6 = null ;

		   
		    
		   String a1= DataSource1.getText();
		   String a2= DataSource2.getText();
		   String a3= DataSource3.getText();
		   String a4= DataSource4.getText();
		   String a5= DataSource5.getText();
		   String a6= DataSource6.getText();
		   String a7= DataSource7.getText();
		   String a8= DataSource8.getText();
		        
		    
		        String sql2 = "Truncate student1";

		        pstm2 = (PreparedStatement) con.prepareStatement(sql2);

		    

		        pstm2.execute();
		       

		        String sql22 = "INSERT INTO student1 VALUES('"+a1+"','"+a2+"','"+a3+"','"+a4+"','"+a5+"','"+a6+"','"+a7+"','"+a8+"')";

		        pstm3 = (PreparedStatement) con.prepareStatement(sql22);

		    

		        pstm3.execute();
		    con.commit();
		   
		    con.close();
		   
		    System.out.println("Modified ");
		}catch(ClassNotFoundException e){
		    System.out.println(e);
		}catch(SQLException ex){
		    System.out.println(ex);
		}

		}


	



	private void delete() throws SQLException, ClassNotFoundException, NullPointerException{
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		
		} catch (ClassNotFoundException e1) {

			e1.printStackTrace();
		}

		try {

			con = DriverManager.getConnection("jdbc:mysql://localhost/finalassessmentpaper?autoReconnect=true&useSSL=false",
					"root", "309919");
		} catch (SQLException e) {

			e.printStackTrace();
		}
		try {
			con.setAutoCommit(false);
		} catch (SQLException e) {

			e.printStackTrace();
		}
		PreparedStatement pstm = null;

		String sql = "TRUNCATE student1";
		try {
			pstm = (PreparedStatement) con.prepareStatement(sql);
		} catch (SQLException e) {

			e.printStackTrace();
		}
		try {
			pstm.execute();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		System.out.println("Table Dropped");

		try {
			con.commit();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		try {
			pstm.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		System.out.println("data truncated");

	}


	private void exceltomysql() throws SQLException, ClassNotFoundException, NullPointerException{
		
		


try{
    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","309919");
    con.setAutoCommit(false);
    PreparedStatement pstm = null ;
    PreparedStatement pstm1 = null ;
    PreparedStatement pstm2 = null ;
    PreparedStatement pstm3 = null ;
    PreparedStatement pstm6 = null ;

    try {
    String sql6 = "create database finalassessmentpaper";
    pstm6 = (PreparedStatement) con.prepareStatement(sql6);
    
    pstm6.execute();}
    catch(Exception e) {
    	System.out.println("already present");
    }
    String sql3 = "Use finalassessmentpaper";




         String sql1 = "Create table student1(reg_no varchar(20), roll_no varchar(20), name varchar(30),Father_name varchar(30),Mother_name varchar(30),Course varchar(30),Semester varchar(30),Year varchar (30))";
         pstm3 = (PreparedStatement) con.prepareStatement(sql3);
     
         pstm1 = (PreparedStatement) con.prepareStatement(sql1);
         try {
         pstm3.execute();}
         catch(Exception e) {
         	System.out.println("already present");
         }
      //  pstm.execute();
         try {
        pstm1.execute();
         } catch(Exception e) {
         	System.out.println("already present");
         }
    
   String a1= DataSource1.getText();
   String a2= DataSource2.getText();
   String a3= DataSource3.getText();
   String a4= DataSource4.getText();
   String a5= DataSource5.getText();
   String a6= DataSource6.getText();
   String a7= DataSource7.getText();
   String a8= DataSource8.getText();
        
    
        String sql2 = "INSERT INTO student1 VALUES('"+a1+"','"+a2+"','"+a3+"','"+a4+"','"+a5+"','"+a6+"','"+a7+"','"+a8+"')";

        pstm2 = (PreparedStatement) con.prepareStatement(sql2);

    

        pstm2.execute();
       
    
    con.commit();
   
    con.close();
   
    System.out.println("Record Updated");
}catch(ClassNotFoundException e){
    System.out.println(e);
}catch(SQLException ex){
    System.out.println(ex);
}

}

	private void result() throws FileNotFoundException, DocumentException, ClassNotFoundException, SQLException {
		Document document = new Document();
		PdfWriter.getInstance(document, new FileOutputStream("E:/View Report.pdf"));
		document.open();
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con1 = DriverManager
				.getConnection("jdbc:mysql://localhost/finalassessmentpaper?autoReconnect=true&useSSL=false", "root", "309919");
		String insert = "Select * from student1;";
		Statement stmt = con1.createStatement();
		ResultSet rs = stmt.executeQuery(insert);

		String reg_no;
		String roll_no;
		String name;
		String Father_name;
		String Mother_name;
		String Course;
		String Semester;
		String Year;
		while (rs.next()) {

			reg_no = rs.getString("reg_no");
			roll_no = rs.getString("roll_no");
			name = rs.getString("name");
			Father_name = rs.getString("Father_name");
			Mother_name = rs.getString("Mother_name");
	Course = rs.getString("Course");
			Semester = rs.getString("Semester");
			Year = rs.getString("Year");
			
			
			
			
		}
		PdfPTable table = new PdfPTable(7);
		table.addCell("Reg_No");
		table.addCell("Roll_No");
		table.addCell("Name");
		table.addCell("Father's Name");
		table.addCell("Mother's Name");
		table.addCell("Course");
		table.addCell("Semester");
		table.addCell("Year");
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager
				.getConnection("jdbc:mysql://localhost/finalassessmentpaper?autoReconnect=true&useSSL=false", "root", "309919");

		Statement st = con.createStatement();

		ResultSet r = st.executeQuery(
				"select * from student1");

		while (r.next()) {

			table.addCell(r.getString("reg_no"));
			table.addCell(r.getString("roll_no"));
			table.addCell(r.getString("name"));
			table.addCell(r.getString("Father_name"));
			table.addCell(r.getString("Mother_name"));
			table.addCell(r.getString("Course"));
			table.addCell(r.getString("Semester"));
			table.addCell(r.getString("Year"));
		}

		document.add(table);
		document.close();

	}




	private void setupTextUI(TextField t, String ff, double f, double w, Pos p, double x, double y, boolean e) {
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
	}

	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}

	/**********************************************************************************************
	 * 
	 * User Interface Actions
	 * 
	 **********************************************************************************************/

	
}